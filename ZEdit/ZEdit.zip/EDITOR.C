#include <Allegro.h>
#include "Editor.h"

EDITOR Editor;

